#pragma once
#include "ExportControl.h"

class PipelineExport : public ExportControl {
private:
    double capacity;
    double pressure;
public:

    // Перегрузка операторов
    bool operator==(const PipelineExport& other) const;
    bool operator<(const PipelineExport& other) const;
    PipelineExport operator+(const PipelineExport& other) const;
    PipelineExport& operator++(); // префикс
    PipelineExport();
    PipelineExport(double v, int c, double cap, double pres);

    void scheduleShipment() override;
    void trackDelivery() override;
    double calculateCost() const override;
    double calculateProfit() const override;
    void print() const override;

    double getCapacity() const;
    void setCapacity(double c);
    double getPressure() const;
    void setPressure(double p);
};
