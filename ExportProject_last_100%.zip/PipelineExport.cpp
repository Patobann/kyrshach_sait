#include "PipelineExport.h"
#include <iostream>

PipelineExport::PipelineExport() : ExportControl(), capacity(0), pressure(0) {}
PipelineExport::PipelineExport(double v, int c, double cap, double pres)
    : ExportControl(v, c), capacity(cap), pressure(pres) {}

void PipelineExport::scheduleShipment() {
    std::cout << "Трубопровод: поставка запланирована при давлении " << pressure
              << " и пропускной способности " << capacity << std::endl;
}

void PipelineExport::trackDelivery() {
    std::cout << "Трубопровод: доставка отслеживается по датчикам давления.\n";
}

double PipelineExport::calculateCost() const {
    return volume * pressure / (capacity > 0 ? capacity : 1);
}

double PipelineExport::calculateProfit() const {
    return calculateCost() * 0.2;
}

void PipelineExport::print() const {
    std::cout << "Трубопровод: объем=" << volume
              << ", кол-во=" << count
              << ", проп.спос-ть=" << capacity
              << ", давление=" << pressure << std::endl;
}

double PipelineExport::getCapacity() const { return capacity; }
void PipelineExport::setCapacity(double c) { capacity = c; }
double PipelineExport::getPressure() const { return pressure; }
void PipelineExport::setPressure(double p) { pressure = p; }

// Перегрузка оператора "=="
bool PipelineExport::operator==(const PipelineExport& other) const {
    return volume == other.volume &&
           count == other.count &&
           capacity == other.capacity &&
           pressure == other.pressure;
}

// Перегрузка оператора "<"
bool PipelineExport::operator<(const PipelineExport& other) const {
    return volume < other.volume;
}

// Перегрузка оператора "+"
PipelineExport PipelineExport::operator+(const PipelineExport& other) const {
    return PipelineExport(
        volume + other.volume,
        count + other.count,
        capacity + other.capacity,
        pressure + other.pressure
    );
}

// Перегрузка оператора "++" (префикс)
PipelineExport& PipelineExport::operator++() {
    ++volume;
    ++count;
    ++capacity;
    ++pressure;
    return *this;
}
