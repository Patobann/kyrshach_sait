#pragma once
class IExportEfficiency {
public:
    virtual double calculateCost() const = 0;
    virtual double calculateProfit() const = 0;
    virtual ~IExportEfficiency() {}
};
