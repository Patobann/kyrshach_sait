#pragma once
#include "ExportControl.h"
#include <string>

class MarineExport : public ExportControl {
private:
    double tankerVolume;
    std::string route;
public:
    MarineExport();
    MarineExport(double v, int c, double tVol, const std::string& r);

    void scheduleShipment() override;
    void trackDelivery() override;
    double calculateCost() const override;
    double calculateProfit() const override;
    void print() const override;

    double getTankerVolume() const;
    void setTankerVolume(double t);
    std::string getRoute() const;
    void setRoute(const std::string& r);
};
