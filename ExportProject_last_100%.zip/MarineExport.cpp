#include "MarineExport.h"
#include <iostream>

MarineExport::MarineExport() : ExportControl(), tankerVolume(0), route("не задан") {}
MarineExport::MarineExport(double v, int c, double tVol, const std::string& r)
    : ExportControl(v, c), tankerVolume(tVol), route(r) {}

void MarineExport::scheduleShipment() {
    std::cout << "Морской экспорт: поставка танкером по маршруту " << route << std::endl;
}

void MarineExport::trackDelivery() {
    std::cout << "Морской экспорт: отслеживание по GPS танкера.\n";
}

double MarineExport::calculateCost() const {
    return volume * 3 + route.length() * 2;
}

double MarineExport::calculateProfit() const {
    return calculateCost() * 0.15;
}

void MarineExport::print() const {
    std::cout << "Морской экспорт: объем=" << volume
              << ", кол-во=" << count
              << ", объем танкера=" << tankerVolume
              << ", маршрут=" << route << std::endl;
}

double MarineExport::getTankerVolume() const { return tankerVolume; }
void MarineExport::setTankerVolume(double t) { tankerVolume = t; }
std::string MarineExport::getRoute() const { return route; }
void MarineExport::setRoute(const std::string& r) { route = r; }
