#include "PipelineExport.h"
#include "MarineExport.h"
#include "RailExport.h"
#include "TruckExport.h"
#include <vector>
#include <memory>
#include <iostream>
#include <fstream>
#include <limits>
#include <exception>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

void printMenu() {
    std::cout << "\n=== МЕНЮ ===\n";
    std::cout << "1. Добавить поставку\n";
    std::cout << "2. Удалить поставку\n";
    std::cout << "3. Показать все поставки\n";
    std::cout << "4. Проверить перегрузку операторов\n";
    std::cout << "5. Сохранить в файл\n";
    std::cout << "6. Загрузить из файла\n";
    std::cout << "7. Выйти\n";
    std::cout << "Выберите пункт: ";
}

std::shared_ptr<ExportControl> createExport() {
    std::cout << "Выберите тип поставки:\n";
    std::cout << "1. Трубопровод\n";
    std::cout << "2. Морской\n";
    std::cout << "3. Железнодорожный\n";
    std::cout << "4. Автотранспорт\n";
    int type;
    std::cin >> type;

    double volume;
    int count;

    std::cout << "Введите объем: ";
    std::cin >> volume;
    std::cout << "Введите количество: ";
    std::cin >> count;

    if (type == 1) {
        double capacity, pressure;
        std::cout << "Введите пропускную способность: ";
        std::cin >> capacity;
        std::cout << "Введите давление: ";
        std::cin >> pressure;
        return std::make_shared<PipelineExport>(volume, count, capacity, pressure);
    }
    else if (type == 2) {
        double tankerVolume;
        std::string route;
        std::cout << "Введите объем танкера: ";
        std::cin >> tankerVolume;
        std::cin.ignore();
        std::cout << "Введите маршрут: ";
        std::getline(std::cin, route);
        return std::make_shared<MarineExport>(volume, count, tankerVolume, route);
    }
    else if (type == 3) {
        int wagonCount;
        std::string fuelType;
        std::cout << "Введите количество вагонов: ";
        std::cin >> wagonCount;
        std::cin.ignore();
        std::cout << "Введите тип топлива: ";
        std::getline(std::cin, fuelType);
        return std::make_shared<RailExport>(volume, count, wagonCount, fuelType);
    }
    else if (type == 4) {
        double loadCapacity, distance;
        std::cout << "Введите грузоподъемность: ";
        std::cin >> loadCapacity;
        std::cout << "Введите расстояние: ";
        std::cin >> distance;
        return std::make_shared<TruckExport>(volume, count, loadCapacity, distance);
    }
    else {
        std::cout << "Некорректный выбор!\n";
        return nullptr;
    }
}

void saveToFile(const std::vector<std::shared_ptr<ExportControl>>& exports, const std::string& filename) {
    std::ofstream out(filename);
    if (!out)
        throw std::runtime_error("Ошибка открытия файла для записи!");

    for (const auto& e : exports) {
        // Пример: только базовая информация (реализуй детализацию по типу, если хочешь)
        out << e->getVolume() << ',' << e->getCount() << '\n';
    }
    out.close();
    std::cout << "Данные сохранены в " << filename << "\n";
}

void loadFromFile(std::vector<std::shared_ptr<ExportControl>>& exports, const std::string& filename) {
    std::ifstream in(filename);
    if (!in)
        throw std::runtime_error("Ошибка открытия файла для чтения!");

    double volume;
    int count;
    char sep;
    exports.clear();
    while (in >> volume >> sep >> count) {
        // По умолчанию добавляем как PipelineExport
        exports.push_back(std::make_shared<PipelineExport>(volume, count, 100, 10));
    }
    in.close();
    std::cout << "Загружено " << exports.size() << " поставок.\n";
}

void testOperators() {
    std::cout << "=== ТЕСТИРОВАНИЕ ПЕРЕГРУЗКИ ОПЕРАТОРОВ ===\n";
    PipelineExport p1(100, 2, 50, 5);
    PipelineExport p2(200, 2, 50, 5);
    PipelineExport p3 = p1;
    std::cout << "p1 == p3: " << (p1 == p3 ? "ДА" : "НЕТ") << "\n";
    std::cout << "p1 < p2: " << (p1 < p2 ? "ДА" : "НЕТ") << "\n";
    ++p1;
    std::cout << "После ++p1: "; p1.print();
    PipelineExport p4 = p1 + p2;
    std::cout << "p4 = p1 + p2: "; p4.print();
}

int main() {
    #ifdef _WIN32
    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);
    #endif

    std::vector<std::shared_ptr<ExportControl>> exports;

    int choice;
    do {
        printMenu();
        std::cin >> choice;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Ошибка ввода!\n";
            continue;
        }
        try {
            switch (choice) {
                case 1: {
                    auto exportPtr = createExport();
                    if (exportPtr) {
                        exports.push_back(exportPtr);
                        std::cout << "Поставка добавлена!\n";
                    }
                    break;
                }
                case 2: {
                    std::cout << "Введите номер поставки для удаления: ";
                    size_t idx;
                    std::cin >> idx;
                    if (idx < 1 || idx > exports.size())
                        throw std::out_of_range("Нет такого элемента!");
                    exports.erase(exports.begin() + (idx - 1));
                    std::cout << "Поставка удалена!\n";
                    break;
                }
                case 3:
                    std::cout << "\nВсе поставки:\n";
                    for (size_t i = 0; i < exports.size(); ++i) {
                        std::cout << "Поставка #" << (i + 1) << ":\n";
                        exports[i]->print();
                        std::cout << std::endl;
                    }
                    if (exports.empty())
                        std::cout << "Нет поставок!\n";
                    break;
                case 4:
                    testOperators();
                    break;
                case 5:
                    saveToFile(exports, "exports_test.txt");
                    break;
                case 6:
                    loadFromFile(exports, "exports_test.txt");
                    break;
                case 7:
                    std::cout << "Выход...\n";
                    break;
                default:
                    std::cout << "Некорректный пункт!\n";
            }
        } catch (const std::exception& ex) {
            std::cout << "Ошибка: " << ex.what() << std::endl;
        }
    } while (choice != 7);

    return 0;
}
