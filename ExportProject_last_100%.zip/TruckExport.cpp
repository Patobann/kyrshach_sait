#include "TruckExport.h"
#include <iostream>

TruckExport::TruckExport() : ExportControl(), loadCapacity(0), distance(0) {}
TruckExport::TruckExport(double v, int c, double lCap, double dist)
    : ExportControl(v, c), loadCapacity(lCap), distance(dist) {}

void TruckExport::scheduleShipment() {
    std::cout << "Автоэкспорт: отправка грузовиком грузоподъемностью " << loadCapacity
              << " тонн на расстояние " << distance << " км." << std::endl;
}

void TruckExport::trackDelivery() {
    std::cout << "Автоэкспорт: отслеживание через GPS и путевые листы.\n";
}

double TruckExport::calculateCost() const {
    return volume * 1.5 + distance * 2;
}

double TruckExport::calculateProfit() const {
    return calculateCost() * 0.10;
}

void TruckExport::print() const {
    std::cout << "Автоэкспорт: объем=" << volume
              << ", кол-во=" << count
              << ", грузоподъемность=" << loadCapacity
              << ", расстояние=" << distance << std::endl;
}

double TruckExport::getLoadCapacity() const { return loadCapacity; }
void TruckExport::setLoadCapacity(double l) { loadCapacity = l; }
double TruckExport::getDistance() const { return distance; }
void TruckExport::setDistance(double d) { distance = d; }
