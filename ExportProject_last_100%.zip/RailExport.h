#pragma once
#include "ExportControl.h"
#include <string>

class RailExport : public ExportControl {
private:
    int wagonCount;
    std::string fuelType;
public:
    RailExport();
    RailExport(double v, int c, int wCount, const std::string& fType);

    void scheduleShipment() override;
    void trackDelivery() override;
    double calculateCost() const override;
    double calculateProfit() const override;
    void print() const override;

    int getWagonCount() const;
    void setWagonCount(int w);
    std::string getFuelType() const;
    void setFuelType(const std::string& f);
};
