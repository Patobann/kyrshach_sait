#include "RailExport.h"
#include <iostream>

RailExport::RailExport() : ExportControl(), wagonCount(0), fuelType("не задан") {}
RailExport::RailExport(double v, int c, int wCount, const std::string& fType)
    : ExportControl(v, c), wagonCount(wCount), fuelType(fType) {}

void RailExport::scheduleShipment() {
    std::cout << "Ж/д экспорт: отправка " << wagonCount << " вагонами, топливо: " << fuelType << std::endl;
}

void RailExport::trackDelivery() {
    std::cout << "Ж/д экспорт: отслеживание по номеру состава.\n";
}

double RailExport::calculateCost() const {
    return volume * 2 + wagonCount * 100;
}

double RailExport::calculateProfit() const {
    return calculateCost() * 0.12;
}

void RailExport::print() const {
    std::cout << "Ж/д экспорт: объем=" << volume
              << ", кол-во=" << count
              << ", вагоны=" << wagonCount
              << ", топливо=" << fuelType << std::endl;
}

int RailExport::getWagonCount() const { return wagonCount; }
void RailExport::setWagonCount(int w) { wagonCount = w; }
std::string RailExport::getFuelType() const { return fuelType; }
void RailExport::setFuelType(const std::string& f) { fuelType = f; }
