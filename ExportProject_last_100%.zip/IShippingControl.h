#pragma once
class IShippingControl {
public:
    virtual void scheduleShipment() = 0;
    virtual void trackDelivery() = 0;
    virtual ~IShippingControl() {}
};
