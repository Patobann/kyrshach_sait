#pragma once
#include "ExportControl.h"

class TruckExport : public ExportControl {
private:
    double loadCapacity;
    double distance;
public:
    TruckExport();
    TruckExport(double v, int c, double lCap, double dist);

    void scheduleShipment() override;
    void trackDelivery() override;
    double calculateCost() const override;
    double calculateProfit() const override;
    void print() const override;

    double getLoadCapacity() const;
    void setLoadCapacity(double l);
    double getDistance() const;
    void setDistance(double d);
};
