#include "ExportControl.h"

ExportControl::ExportControl() : volume(0), count(0) {}
ExportControl::ExportControl(double v, int c) : volume(v), count(c) {}
ExportControl::~ExportControl() {}

double ExportControl::getVolume() const { return volume; }
void ExportControl::setVolume(double v) { volume = v; }
int ExportControl::getCount() const { return count; }
void ExportControl::setCount(int c) { count = c; }
