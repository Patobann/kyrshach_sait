#pragma once
#include "IShippingControl.h"
#include "IExportEfficiency.h"

class ExportControl : public IShippingControl, public IExportEfficiency {
protected:
    double volume;
    int count;
public:
    ExportControl();
    ExportControl(double v, int c);
    virtual ~ExportControl();

    virtual void scheduleShipment() = 0;
    virtual void trackDelivery() = 0;
    virtual double calculateCost() const = 0;
    virtual double calculateProfit() const = 0;
    virtual void print() const = 0;

    double getVolume() const;
    void setVolume(double v);
    int getCount() const;
    void setCount(int c);
};
